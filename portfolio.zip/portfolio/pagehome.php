<?php
Template Name: Home
?>
<?php get_header();?>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="keywords" content="HTML,CSS">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>VIATOP Serviços Topográficos </title>
    <meta name="description" content="Premium Responsive Bootstrap 5 Personal Template" />
    <meta name="keywords" content="bootstrap 5, premium, cv, personal, Portfolio, multipurpose" />
    <meta name="author" content="SRBThemes" />
   <link rel="shortcut icon" href="<?php echo get_theme_root_uri();?>/portfolio/images/logovt.png">

    <!-- Bootstrap Css -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_theme_root_uri();?>/portfolio/css/bootstrap.min.css">

    <!-- Materialdesign icons Css -->

    <!-- Owl Carousel -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_theme_root_uri();?>/portfolio/css/owl.carousel.min.css">

    <!-- Animate Css -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_theme_root_uri();?>/portfolio/css/animate.min.css">

    <!-- Magnific-popup -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_theme_root_uri();?>/portfolio/css/magnific-popup.css">

    <!-- Mobirise icons Css -->
    <link rel="stylesheet" type="text/css" href="<?php echo get_theme_root_uri();?>/portfolio/css/mobiriseicons.css">

    <!-- Custom Style -->
    <link href="<?php echo get_theme_root_uri();?>/portfolio/style.css" rel="stylesheet" >
    <link href="<?php echo get_theme_root_uri();?>/portfolio/css/default.css" id="option-color" rel="stylesheet" >
    </head>
<body>

    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner">Loading...</div>
        </div>
    </div>

	<!-- Start Navbar -->
	<nav class="navbar navbar-expand-lg custom-nav navbar-light fixed-top sticky">
	    <div class="container">
	        <a class="navbar-brand pt-0 logo" <link href="https://wa.me/5512996546149?text=Ol%C3%A1+tudo+bem%3F+Agradecemos+pelo+contato%2C+deixe+sua+mensagem+que+logo+um+de+nossos+profissionais+ir%C3%A1+atend%C3%AA-lo.">>
                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/logo1.png" alt="" class="img-fluid logo-light">
                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/logoblackwhats.jpg" alt="" class="img-fluid logo-dark">
            </a>
	        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	            <span class="mdi mdi-menu"></span>
	        </button>
	        <div class="collapse navbar-collapse" id="navbarNav">
	            <ul class="navbar-nav ms-auto" id="main_nav">
	                <li class="nav-item">
	                    <a class="nav-link" href="#home">Home</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="#about">Sobre</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="#services">Serviços</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="#client">Clientes</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="#portfolio">Portfolio</a>
	                </li>
	                <!--<li class="nav-item">
	                    <a class="nav-link" href="#blog">Blog</a>
	                </li>-->
	                <li class="nav-item">
	                    <a class="nav-link" href="#contact">Contato</a>
	                </li>
	            </ul>
	        </div>
	    </div>
	</nav>
	<!-- End Navbar -->


    <!-- START HOME -->
    <section class="section header-bg-img h-100vh align-items-center d-flex" id="home">
        <div class="bg-overlay"></div>
        <div class="container z-index">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="text-center header-content mx-auto">
                        <h4 class="text-white first-title mb-4"></h4>
                        <h1 class="header-name text-white text-capitalize mb-0">Somos a <p><span class="element fw-bold"></span></p> </h1>
                        <p class="text-white mx-auto header-desc mt-4">  Topografia na medida certa!</p>
                        <div class="mt-4 pt-2">
                            <a href="https://wa.me/5512996546149?text=Ol%C3%A1+tudo+bem%3F+Agradecemos+pelo+contato%2C+deixe+sua+mensagem+que+logo+um+de+nossos+profissionais+ir%C3%A1+atend%C3%AA-lo." 
                            class="btn btn-outline-custom btn-round">Faça um Orçamento</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>            
        <div class="scroll_down">
            <a href="#Sobre " class="scroll">
                <i class="text-white"></i>
            </a>
        </div>
    </section>
    <!-- END HOME -->

    <!-- START ABOUT -->
    <section class="section" id="Sobre">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="mt-3">
                        <img src="<?php echo get_theme_root_uri();?>/portfolio/images/sobre.jpg" alt="" class="img-fluid mx-auto d-block img-thumbnail">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="mt-3">
                        <h2><span class="fw-bold">Sobre</span> Nós</h2>
                        <h4 class="mt-4">Somos a <span class="text-custom fw-bold"> Viatop Serviços Topograficos.</span></h4>
                        <p class="text-muted mt-4">Estamos no mercado desde 2013, prestando serviços de <strong>Topografia</strong> com total qualidade, responsabilidade visando sempre a melhora contínua</p>
                        <p class="text-muted mt-2">Nossa missão é atender com pontualidade, responsabilidade e excelência, estamos sempre a nos atualizar com os melhores equipamentos e técnicas para melhor atender a necessidade de cada cliente.</p>
                        <p class="text-muted mt-2">Desenvolvemos a solução que você precisa, a um preço justo!.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END ABOUT -->

    <!-- START SERVICES -->
    <section class="section bg-light" id="services">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h2><span class="fw-bold">Nossos Serviços</span></h2>
                        <p class="text-muted mx-auto section-subtitle mt-3">Serviços de Topografia executados com base na NBR 13.133, para assegurar a excelência e acurácia necessária para cada trabalho desenvolvido.</p>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"><strong>Locação de <p>Obras</p></strong> </h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"><strong>Levantamento Georreferenciado</strong></h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"><strong>Levantamentos Planialtimétricos</strong></h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"><strong>Desmembramento</strong></h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"><strong></strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"><strong>Retificaçao de Área</strong></h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center services-boxes rounded p-4 mt-4">
                        <div class="services-boxes-icon">
                            <i class="mbri-sucess text-custom display-4"></i>
                        </div>
                        <div class="mt-4">
                            <h5 class="mb-0"<h5><strong>Usucapião</strong></h5>
                            <div class="services-title-border"></div>
                            <p class="text-muted mt-3"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END SERVICES -->

    <!-- START CTA -->
    <!-- END CTA -->

    <!-- START CLIENT -->
    <section class="section bg-light" id="client">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h2>Nossos <span class="fw-bold">Clientes</span></h2>
                        <p class="text-muted mx-auto section-subtitle mt-3"></p>
                    </div>
                </div>
            </div>
            <div class="row mt-4 pt-4">
                <div class="col-lg-12">
                    <div id="owl-demo" class="owl-carousel">
                        <div class="text-center testi_boxes mx-auto">
                            <div class="tam_testi_icon text-custom">
                                <i class="mbri-quote-left"></i>
                            </div>
                            <div class="mt-2">
                                <div class="img_testi">
                                    <img src="<?php echo get_theme_root_uri();?>/portfolio/images/testi/macro.png" alt="" class="mx-auto img-thumbnail img-fluid rounded-circle">
                                </div>
                                <p class="client_review fst-italic mt-4 text-center text-muted">Prestamos serviços para a Macro Engenharia em locação de obras e dando suporte à engenharia.</p>
                            </div>
                        </div>
                        <div class="text-center testi_boxes mx-auto">
                            <div class="tam_testi_icon text-custom">
                                <i class="mbri-quote-left"></i>
                            </div>
                            <div class="mt-2">
                                <div class="img_testi">
                                    <img src="<?php echo get_theme_root_uri();?>/portfolio/images/testi/montante.jfif" alt="" class="mx-auto img-thumbnail img-fluid d-block rounded-circle">
                                </div>
                                <p class="client_review fst-italic mt-4 text-center text-muted">"Excelência em empreendimentos imobiliários,Prestamos Serviços de <strong>Topografia</strong> em fundações e Locação de Obras em Geral"</p>
                                <p class="client_name text-center mb-0 mt-4"><span class="fw-bold"></span></p>
                            </div>
                        </div>
                        <div class="text-center testi_boxes mx-auto">
                            <div class="tam_testi_icon text-custom">
                                <i class="mbri-quote-left"></i>
                            </div>
                            <div class="mt-2">
                                <div class="img_testi">
                                    <img src="<?php echo get_theme_root_uri();?>/portfolio/images/testi/zs.jfif" alt="" class="mx-auto img-thumbnail img-fluid d-block rounded-circle">
                                </div>
                                <p class="client_review fst-italic mt-4 text-center text-muted"> Grupo ZS Urbanismo - Prestamos Serviços de <strong>Topografia</strong> em Loteamentos,desde a Terraplenagem até a entrega da Obra.</p>
                                <p class="client_name text-center mb-0 mt-4">-  <span class="fw-bold"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- END CLIENT -->

    <!-- START WORK -->   
    <section class="section text-center" id="portfolio">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h2> <span class="fw-bold">Portfolio</span></h2>
                        <p class="text-muted mx-auto section-subtitle mt-3">Segue abaixo trabalhos realizados.</p>
                    </div>
                </div>
            </div>
            <div class="row mt-5 ">
                   </div>
        </div>
        <div class="container">
            <div class="row mt-4 work-filter">
                <div class="col-lg-4 work_item webdesign wordpress">
                    <a href="" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/loteamento1.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Grupo ZS Urbanismo</p>
                                <h4 class="mb-0">Loteamento Portal dos Pássaros - SJ Campos SP</h4>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 work_item WORK webdesign seo">
                    <a href="<?php echo get_theme_root_uri();?>/portfolioimages/works/2a.jpg" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/2a.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Terraplenagem</p>
                                <h4 class="mb-0">Loteamento Cambuí - SJCampos</h4>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 work_item seo wordpress">
                    <a href="<?php echo get_theme_root_uri();?>/portfolio/images/works/3a.jpg" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/3a.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Locação de Obra</p>
                                <h4 class="mb-0">Fundação Prédio - Montante Empreendimentos Imobiliários</h4>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 work_item wordpress WORK webdesign">
                    <a href="<?php echo get_theme_root_uri();?>/portfolio/images/works/4a.jpg" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/4a.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Locação de Obra</p>
                                <h4 class="mb-0">Fundação - Macro Engenharia</h4>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 work_item seo webdesign">
                    <a href="<?php echo get_theme_root_uri();?>/portfolio/images/works/5a.jpg" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/5a.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Levantamento Planialtimétrico</p>
                                <h4 class="mb-0">Macro Engenharia</h4>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 work_item devlopment webdesign">
                    <a href="<?php echo get_theme_root_uri();?>/portfolio/images/works/7a.jpg" class="img-zoom">
                        <div class="work_box">
                            <div class="work_img">
                                <img src="<?php echo get_theme_root_uri();?>/portfolio/images/works/7a.jpg" class="img-fluid mx-auto d-block rounded" alt="work-img">
                            </div>
                            <div class="work_detail">
                                <p class="mb-2">Levantamento Georreferenciado</p>
                                <h4 class="mb-0">Macro Engenharia</h4>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- END WORK -->

    <!-- START BLOG -->
    <!-- END BLOG -->

    <!-- START CONTACT -->
    <section class="section" id="contact">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h2><span class="fw-bold">Faça seu Orçamento</span></h2>
                        <p class="text-muted mx-auto section-subtitle mt-3"></p>
                    </div>
                </div>
            </div> 
            <div class="row justify-content-center">
                <div class="col-lg-4">
                    <div class="text-center">
                        <div>
                            <i class="mbri-mobile2 text-custom h1"></i>
                        </div>
                        <div class="mt-3">
                            <h5 class="mb-0 contact_detail-title "> Fale conosco </h5>
                            <p class="text-muted1">+55 12 99654-6149</p>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center"
                <div class="col-lg-4">
                    <div class="text-center">
                        <div>
                            <i class="mbri-letter text-custom h1"></i>
                        </div>
                        <div class="mt-3">
                            <h5 class="mb-0 contact_detail-title ">Email </h5>
                            <h6 class="text-muted2">tobias.viatop@gmail.com</h6>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="text-center">
                        <div>
                            <i class="mbri-pin text-custom h1"></i>
                        </div>
                        <div class="mt-3">
                            <h5 class="mb-0 contact_detail-title">Endereço</h5>
                             <h6 class="text-muted3">Rua São Sebastião, 36, Paraibuna-SP.</h6>
                            <p></p><p></p>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            
                    </div>  
                </div>
            </div>
        </div>
    </section>
    <!-- END CONTACT -->

    <!--START FOOTER-->
    <footer class="footer bg-light">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-12">
                    <div class="text-center text-white footer-alt">
                       
                        <p class="copyright_content mb-0 mt-3"> Todos os direitos reservados &copy;    Viatop Serviços Topográficos - by EJCode</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--END FOOTER-->
    

    <!-- Back To Top -->    
    <a href="#" class="back_top"> <i class="mdi mdi-chevron-up"> </i> </a>

    <!-- START SWITCHER -->
    <div id="color-switcher" style="left: 0px;">
        <div>
            <h3 class="fw-bold text-center">Select your color</h3>
            <ul class="pattern">
                <li>
                    <a class="color1" href="#"></a>
                </li>
                <li>
                    <a class="color2" href="#"></a>
                </li>
                <li>
                    <a class="color3" href="#"></a>
                </li>
                <li>
                    <a class="color4" href="#"></a>
                </li>
                <li>
                    <a class="color5" href="#"></a>
                </li>
                <li>
                    <a class="color6" href="#"></a>
                </li>                   
            </ul>
        </div>
        <div class="bottom">
            <a href="#" class="settings rounded-right"><i class="mdi mdi-settings mdi-spin"></i></a>
        </div>
    </div>
    <!-- END SWITCHER -->


	<!--All Javascript -->
	<script src="<?php echo get_theme_root_uri();?>/portfolio/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/jquery.min.js"></script>
    
    <!-- Text Type -->
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/typed.js"></script>
    
    <!-- Owl Carousel -->
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/owl.carousel.min.js"></script>

    <!-- Switcher Js -->
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/switcher.js"></script>  
    
    <!-- Work Filter -->
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/isotope.js"></script>

    <!-- Magnific Popup Js -->
    <script src="<?php echo get_theme_root_uri();?>/portfolio/js/jquery.magnific-popup.min.js"></script>

	<!-- Custom Js -->
	<script src="<?php echo get_theme_root_uri();?>/portfolio/js/custom.js"></script>
    <script>
        var typed = new Typed('.element', {
            strings: ["Viatop Serviços Topográficos."],
            typeSpeed: 100,
            backSpeed: 40,
            backDelay: 3000,
            loop: true
        });
    </script>
</body>
<?php get_footer();?>
</html>